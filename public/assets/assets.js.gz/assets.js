$(document).ready(function() {

  $('textarea.html').tinymce(TinyMceDefaultSettings);

});
